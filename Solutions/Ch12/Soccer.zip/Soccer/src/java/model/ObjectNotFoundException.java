package model;

public class ObjectNotFoundException extends Exception {

}