package com.gjun;

import com.google.gson.Gson;
import java.io.IOException;
import java.util.concurrent.CopyOnWriteArraySet;
import javax.websocket.OnClose;
import javax.websocket.OnMessage;
import javax.websocket.OnOpen;
import javax.websocket.Session;
import javax.websocket.server.PathParam;
import javax.websocket.server.ServerEndpoint;

@ServerEndpoint("/chatRoom/{id}")
public class ChatService {
    // 用來存放WebSocket已連接的Socket
    static CopyOnWriteArraySet<Session> sessions = new CopyOnWriteArraySet<Session>();

    @OnOpen
    public void onOpen(@PathParam("id")String id, Session session) {
        //記錄連接到sessions中
        sessions.add(session);
        System.out.println("目前連線:" + sessions.size());
        for (Session s : sessions) { // 對每個連接的Client傳送訊息
            if (s.isOpen()) {
                s.getAsyncRemote().sendText("系統:"+id+"加入聊天室");
            }
        }
    }
    
    @OnClose
    public void onClose(@PathParam("id")String id, Session session) {
        //將連從sessions中移除
        sessions.remove(session);
        System.out.println("目前連線:" + sessions.size());
        for (Session s : sessions) { // 對每個連接的Client傳送訊息
            if (s.isOpen()) {
                s.getAsyncRemote().sendText("系統:"+id+"離開聊天室");
            }
        }
    }
    
    @OnMessage
    public void onMessage(String message,Session session) {
        //建構Gson序列化與反序列Json物件
        Gson gson=new Gson();
        //反序列化前端傳遞進來的Json字串
        ChatMessage chatmsg = gson.fromJson(message, ChatMessage.class);
        for (Session s : sessions) { // 對每個連接的Client傳送訊息
            if (s.isOpen()) {
                s.getAsyncRemote().sendText(chatmsg.getId() +":"+chatmsg.getMessage());
            }
        }
    }    
}
