package model;

import java.util.*;

public class AnniversaryModel {
    
    private int year;
    private Map<Integer, String> anniversaryMap;

    public AnniversaryModel() {
        anniversaryMap = new HashMap<Integer, String>();
        populateMap();
    }    

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public String getMaterial(){
        String result = "Nothing";
        if(anniversaryMap.containsKey(year)){
            result = anniversaryMap.get(year);
        }        
        return result;
    }

    private void populateMap(){
        anniversaryMap.put(1, "Paper");
        anniversaryMap.put(2, "Cotton");
        anniversaryMap.put(3, "Leather");
        anniversaryMap.put(4, "Linen, Silk");
        anniversaryMap.put(5, "Wood");
        anniversaryMap.put(6, "Iron");
        anniversaryMap.put(7, "Wool, Copper");
        anniversaryMap.put(8, "Bronze");
        anniversaryMap.put(9, "Pottery, China");
        anniversaryMap.put(10, "Tin, Aluminum");
        anniversaryMap.put(11, "Steel");
        anniversaryMap.put(12, "Silk");
        anniversaryMap.put(13, "Lace");
        anniversaryMap.put(14, "Ivory");
        anniversaryMap.put(15, "Crystal");
        anniversaryMap.put(20, "China");
        anniversaryMap.put(25, "Silver");
        anniversaryMap.put(30, "Pearl");
        anniversaryMap.put(35, "Coral");
        anniversaryMap.put(40, "Ruby");
        anniversaryMap.put(45, "Sapphire");
        anniversaryMap.put(50, "Gold");
        anniversaryMap.put(55, "Emerald");
        anniversaryMap.put(60, "Diamond");
    }
}