package web;

import java.io.*;
import java.util.LinkedList;
import java.util.List;
import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;
import model.DVDItem;

@WebListener()
public class InitializeLibrary implements ServletContextListener {

    @Override
    public void contextInitialized(ServletContextEvent sce) {
        ServletContext context = sce.getServletContext();
        String libraryFile = context.getInitParameter("libraryFile");
        List<DVDItem> dvdList = new LinkedList<>();
        try(InputStream is = context.getResourceAsStream(libraryFile);
            BufferedReader br = new BufferedReader(new InputStreamReader(is))){
            String record;
            while((record=br.readLine())!=null){
                try{
                    String[] data = record.split("\\|");
                    DVDItem dvd =new DVDItem(data[0],data[1],data[2]);
                    dvdList.add(dvd);
                } catch(Exception e){
                    context.log("wrong data:"+record);
                }
            }
            context.setAttribute("DVDList", dvdList);
            context.log("The library file has been loaded!");
        } catch(Exception e){
            context.log("Processing library file exception: " + e);
        }
        String[] genres = context.getInitParameter("genre-list").split(", ");
        context.setAttribute("genreList", genres);
    }

    @Override
    public void contextDestroyed(ServletContextEvent sce) {
        ServletContext context = sce.getServletContext();
        context.log("The Context will be destroyed!");
    }
}
