package service;

import domain.Address;
import domain.Customer;
import java.util.Collection;
import java.util.HashMap;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PUT;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

@Path("customer")
public class CustomerResource {
    
    //測試資料
    private static final HashMap<Integer, Customer> customers = new HashMap<Integer, Customer>();
    static {
        customers.put(1, new Customer("蔡英文", 
                        new Address("凱達格蘭大道1號", "總統府廣場", "台北", "台灣", "100"), 
                        new Address("重慶南路一段122號", "總統府", "台北", "台灣", "100"),
                        new Address("重慶南路二段100號", "總統官邸", "台北", "台灣", "100")));
        customers.put(2, new Customer("柯文哲", 
                        new Address("市府路1號", "台北市政府", "台北", "台灣", "110"), 
                        null,
                        new Address("徐州路46號", "台北市長官邸", "台北", "台灣", "100")));
    }

    public static Customer getCustomer(int id) {
        return customers.get(id);
    }

    public static Collection<Customer> getCustomers() {
        return customers.values();
    }
    
    @Path("{id}")
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    public Response addCustomer(@PathParam("id")Integer id, Customer customer){
        if(customers.containsKey(id)){
            return Response.status(400).build();
        } else {
            customers.put(id, customer);
            return Response.ok()
                .header("status","ok")
                .encoding("UTF-8")
                .entity(customers)
                .build();
        }
    }
    
    @Path("{id}")
    @PUT
    @Consumes(MediaType.APPLICATION_JSON)
    public Response updateUser(@PathParam("id")Integer id, Customer customer){
        if(customers.containsKey(id)){
            customers.put(id, customer);
            return Response.ok()
                .header("status","ok")
                .encoding("UTF-8")
                .entity(customers)
                .build();
        } else {
            return Response.status(400).build();
        }
    }
    
    @Path("{id}")
    @DELETE
    public Response deleteUser(@PathParam("id")Integer id){
        if(customers.containsKey(id)){
            customers.remove(id);
            return Response.ok()
                .header("status","ok")
                .encoding("UTF-8")
                .entity(customers)
                .build();
        } else {
            return Response.status(400).build();
        }
    }
}
