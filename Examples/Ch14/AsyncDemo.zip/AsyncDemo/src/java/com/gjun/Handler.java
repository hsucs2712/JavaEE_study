package com.gjun;

import java.util.Date;
import javax.servlet.AsyncContext;
import javax.servlet.ServletRequest;

public class Handler implements Runnable {

    private AsyncContext actx;
    private static final String[] words = {
        "long", "short", "big", "small", "clever", "foolish", "tidy", "disorganized"
    };
    
    public Handler(AsyncContext actx) {
        this.actx = actx;
    }
    
    @Override
    public void run() {        
        System.out.println("非同步執行緒啟動:"+new Date());
        try {
            Thread.sleep(5000 + ((int) (Math.random() * 5000)));
        } catch (InterruptedException ex) {
            ex.printStackTrace();
        }
        ServletRequest request = actx.getRequest();
        String word = words[(int) (Math.random() * words.length)];   
        int num = (int)(Math.random()*100);     
        request.setAttribute("word", word); 
        request.setAttribute("num", num);    
        System.out.println("非同步執行緒結束:"+new Date());        
        actx.dispatch("/asyncView.jsp");
    }
    
}
