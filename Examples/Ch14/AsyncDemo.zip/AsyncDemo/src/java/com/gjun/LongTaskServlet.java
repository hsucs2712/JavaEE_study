package com.gjun;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/LongTask")
public class LongTaskServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) 
                                throws ServletException, IOException {
        resp.setContentType("text/html;charset=UTF-8");
        PrintWriter out = resp.getWriter();
        out.print("1.進入Servlet的時間： " + new Date() + " <br> <br>");
        
        // 商業邏輯 !
        longTask(out);
        
        out.print("3.結束Servlet的時間：" + new Date() + " <br> <br>");
    }
    
    private void longTask(PrintWriter out) {
        try {
            Thread.sleep(10000);
            out.print("2.任務處理完畢的時間：" + new Date() + " <br> <br>");
        } catch (Exception e) {
        }
    }
    
}

