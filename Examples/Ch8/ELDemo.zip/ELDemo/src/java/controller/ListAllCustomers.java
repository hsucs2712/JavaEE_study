package controller;

import java.io.*;
import beans.*;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.WebServlet;


@WebServlet(name = "ListAllCustomers", urlPatterns = {"/ListAllCustomers"})
public class ListAllCustomers extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        CustomerBean[] customers = new CustomerBean[3];
        String[] phone1 ={"0987-654-321", "02-2345-6789"};
        String[] phone2 = {"04-2345-4321", "0923-456-789"};
        customers[0]=new CustomerBean("Sean Cheng", "sean.chen@gmail.com", phone1, 19);
        customers[1]=new CustomerBean("David Wang", "david.wang@gmail.com", phone2, 16);
        customers[2]=new CustomerBean("Louis Lin", "louis.lin@gmail.com",null, 20);
        
       request.setAttribute("customers", customers);
       RequestDispatcher rd = request.getRequestDispatcher("list_customers.jsp");
       rd.forward(request, response);
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

}
