package model;
import javax.servlet.*;

public class RegistrationService {
    private League league;
    private Player player;

    public RegistrationService(League league, Player player) {
        this.league = league;
        this.player = player;
    }

    public void setLeague(League league) {
        this.league = league;
    }

    public void setPlayer(Player player) {
        this.player = player;
    }

    public League getLeague() {
        return league;
    }

    public Player getPlayer() {
        return player;
    }
    
    public void register(){
        System.out.println("creating Player : " + player.getName() );
        System.out.println("Register to " + league.getTitle() + " League!");
    }
}
