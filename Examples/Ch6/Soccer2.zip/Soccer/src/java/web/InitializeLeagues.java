package web;
import javax.servlet.*;
import java.util.*;
import java.io.*;
import javax.servlet.annotation.*;
import model.League;

@WebListener
public class InitializeLeagues implements ServletContextListener {

    @Override
    public void contextInitialized(ServletContextEvent sce) {
        ServletContext context = sce.getServletContext();
        List leagueList = new LinkedList();
        String leaguesFile = context.getInitParameter("leaguesFile");
        InputStream is = null;
        BufferedReader reader = null;
        try {
            is = context.getResourceAsStream(leaguesFile);
            reader = new BufferedReader(new InputStreamReader(is));
            String record;
            // Read every record (one per line)
            while ( (record = reader.readLine()) != null ) {
                String[] fields = record.split("\t");
                // Extract the data fields for the record
                int year = Integer.parseInt(fields[0]);
                String season = fields[1];
                String title = fields[2];
                // Add the new League item to the list
                League item = new League(year, season, title);
                leagueList.add(item);
            }
            context.setAttribute("leagueList", leagueList);
            context.log("The league list has been loaded.");           
        } catch(Exception e){
            context.log("Exception occured while processing the leagues file.", e);
        } finally {
            if ( is != null ) {
                try { is.close(); } catch (Exception e) {}
            }
            if ( reader != null ) {
                try { reader.close(); } catch (Exception e) {}
            }
        }
    }

    @Override
    public void contextDestroyed(ServletContextEvent sce) {
        ServletContext context = sce.getServletContext();
        context.log("The Context will be destroyed.");
    }
    
}
