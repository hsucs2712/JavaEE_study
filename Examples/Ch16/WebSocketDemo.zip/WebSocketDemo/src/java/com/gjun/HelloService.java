package com.gjun;

import javax.websocket.OnMessage;
import javax.websocket.server.ServerEndpoint;

@ServerEndpoint("/hello")
public class HelloService {

    @OnMessage
    public String onMessage(String message) {
        return String.format("Hello, %s", message);
    }
    
}
