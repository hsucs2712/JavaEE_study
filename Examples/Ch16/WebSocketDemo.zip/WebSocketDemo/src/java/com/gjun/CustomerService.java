package com.gjun;

import com.google.gson.Gson;
import javax.websocket.OnMessage;
import javax.websocket.server.PathParam;
import javax.websocket.server.ServerEndpoint;

@ServerEndpoint("/customer/{cid}")
public class CustomerService {

    @OnMessage
    public String getCustomer(@PathParam("cid")String customerid,String message) {
        Customer customer=new Customer();
        customer.setId(customerid);
        customer.setName(message);
        customer.setAddress("台北市");     
        Gson gson=new Gson();       
        return gson.toJson(customer);
    }
    
}
