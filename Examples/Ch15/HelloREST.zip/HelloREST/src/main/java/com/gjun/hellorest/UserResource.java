package com.gjun.hellorest;

import com.gjun.domain.Message;
import com.gjun.domain.User;
import java.util.Collection;
import java.util.Map;
import java.util.TreeMap;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.Produces;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PUT;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.MediaType;

@Path("user")
public class UserResource {
    private static Map<Integer, User> users = new TreeMap<>();
    static{
        users.put(1, new User(1, "Sean", 36));
        users.put(2, new User(2, "David", 28));
    }
    
    // 查詢所有 User
    @Path("users")
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Collection getUsers(){
        return users.values();
    }
    
    // 查詢指定id User
    @Path("user/{id}")
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public User getUser(@PathParam("id")Integer id){
        return users.get(id);
    }

    // 新增 User
    @Path("user")
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    public Message addUser(User user){
        Message msg = new Message();
        Integer id = user.getId();
        if(users.containsKey(id)){
            msg.setMessage(String.format("user%d已存在, 新增失敗!", id));
            msg.setCode(500);
        } else {
            users.put(id, user);
            msg.setMessage(String.format("新增%s(%d)成功", user.getName(), user.getAge()));
            msg.setCode(200);            
        }
        return msg;
    }
    
    // 更新 User
    @Path("user/{id}")
    @PUT
    @Consumes(MediaType.APPLICATION_JSON)
    public Message updateUser(@PathParam("id")Integer id, User user){
        Message msg = new Message();
        if(users.containsKey(id) && user.getId().equals(id)){
            users.put(user.getId(), user);
            msg.setMessage(String.format("更新%s(%d)成功", user.getName(), user.getAge()));
            msg.setCode(200);
        } else {
            msg.setMessage(String.format("user%d更新失敗!", user.getId()));
            msg.setCode(500);
        }
        return msg;
    }

    // 刪除 User
    @Path("user/{id}")
    @DELETE
    public Message deleteUser(@PathParam("id")Integer id){
        Message msg = new Message();
        if(users.containsKey(id)){
            users.remove(id);
            msg.setMessage(String.format("user%d刪除成功", id));
            msg.setCode(200);
        } else {
            msg.setMessage(String.format("user%d刪除失敗!", id));
            msg.setCode(500);
        }
        return msg;
    }
    
}

