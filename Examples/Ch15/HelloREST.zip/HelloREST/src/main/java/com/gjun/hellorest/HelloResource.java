package com.gjun.hellorest;

import javax.ws.rs.Produces;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

//  http://localhost:8080/HelloREST/webresources/hellos
@Path("hellos")
public class HelloResource {
    
    @GET
    @Produces(MediaType.TEXT_HTML)
    public String hello() {
        return "<h3>Hello REST Web Service<h3>";
    }
    
    //  webresources/hellos/hello?name=Sean
    @Path("hello")
    @GET
    @Produces(MediaType.TEXT_HTML)
    public String helloParam(@QueryParam("name")String who) {
        return String.format("<h3>Hello %s<h3>", who);
    }
    
    //  webresources/hellos/hi/{msg}/
    @Path("hi/{msg}/")
    @GET
    @Produces(MediaType.TEXT_HTML)
    public String helloPath(@PathParam("msg")String message) {
        return String.format("<h3>Hi, %s<h3>", message);
    }
    
}
