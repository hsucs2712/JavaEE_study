package controller;

import java.io.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.WebServlet;
import model.*;

@WebServlet(name = "AddLeague", urlPatterns = {"/admin/AddLeague"})
public class AddLeague extends HttpServlet {
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Keep a set of strings to record form processing errors.
        List errorMsgs = new LinkedList();
        // Store this set in the request scope, in case we need to send the ErrorPage.
        request.setAttribute("errorMsgs", errorMsgs);
        try {
            // Retrieve form parameters.
            String yearStr = request.getParameter("year").trim();
            String season = request.getParameter("season").trim();
            String title = request.getParameter("title").trim();
            // Perform data conversions.
            int year = -1;
            try {
                year = Integer.parseInt(yearStr);
            } catch (NumberFormatException nfe) {
                errorMsgs.add("The 'year' field must be a positive integer.");
            }
            // Verify form parameters
            if ( (year != -1) && ((year < 2010) || (year > 2025)) ) {
                errorMsgs.add("The 'year' field must within 2010 to 2025.");
            }
            if ( season.equals("UNKNOWN") ) {
                errorMsgs.add("Please select a league season.");
            }
            if ( title.length() == 0 ) {
                errorMsgs.add("Please enter the title of the league.");
            }
            // Send the ErrorPage view if there were errors
            if ( ! errorMsgs.isEmpty() ) {
                RequestDispatcher view
                        = request.getRequestDispatcher("/admin/error.jsp");
                view.forward(request, response);
                return;
            }
            // Perform business logic
            League league = new League(year, season, title);
            // Store the new league in the leagueList context-scope attribute
            ServletContext context = getServletContext();
            List leagueList = (List) context.getAttribute("leagueList");
            if(leagueList==null) {
                leagueList = new LinkedList();
                context.setAttribute("leagueList", leagueList);
            }
            leagueList.add(league);
            // Store the new league in the request-scope
            request.setAttribute("league", league);

            // Send the Success view
            RequestDispatcher view = request.getRequestDispatcher("/admin/success.jsp");
            view.forward(request, response);
            
        } catch (RuntimeException e) {
            errorMsgs.add(e.getMessage());
            RequestDispatcher view = request.getRequestDispatcher("/admin/error.jsp");
            view.forward(request, response);
            // Log stack trace
            this.log(e.toString());
        } // END of try-catch block
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP
     * <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP
     * <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>
}
