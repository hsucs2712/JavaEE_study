package model;

// 引入Utility 類別
import java.util.List;

public class LeagueService {
    //宣告服務元件所使用之LeagueDAO物件
    private LeagueDAO leagueDataAccess;
    //建構子, 初始化LeagueDAO物件
    public LeagueService() {
        leagueDataAccess = new LeagueDAO();
    }
    //取得所有聯盟.使用LeagueDAO
    public List<League> getAllLeagues() {
        return leagueDataAccess.retrieveAll();
    }

    //新增聯盟至資料庫
    public League createLeague(int year, String season, String title) {
        // 建立聯盟物件,ObjectID未知,以-1帶入
        League league = new League(-1, year, season, title);
        //新增聯盟至資料庫
        leagueDataAccess.insert(league);
        return league;
    }    
}
