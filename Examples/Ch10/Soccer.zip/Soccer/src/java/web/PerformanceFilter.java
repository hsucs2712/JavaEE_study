package web;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.WebFilter;
import javax.servlet.annotation.WebInitParam;

@WebFilter(filterName = "perfFilter", urlPatterns = {"/*"}, initParams = {
    @WebInitParam(name = "Log Entry Prefix", value = "Performance : ")})
public class PerformanceFilter implements Filter {

    private FilterConfig config;
    private String logPrefix;

    public void init(FilterConfig config) throws ServletException {
        this.config = config;
        logPrefix = config.getInitParameter("Log Entry Prefix");
    }

    public void doFilter(ServletRequest request, ServletResponse response, 
                FilterChain chain) throws ServletException, IOException {

        long begin = System.currentTimeMillis();
        chain.doFilter(request, response);
        long end = System.currentTimeMillis();

        StringBuffer logMessage = new StringBuffer();
        if (request instanceof HttpServletRequest) {
            logMessage = ((HttpServletRequest)request).getRequestURL();
        }
        logMessage.append(": ");
        logMessage.append(end - begin);
        logMessage.append(" ms");

        if(logPrefix != null) {
            logMessage.insert(0,logPrefix);
        }

        config.getServletContext().log(logMessage.toString());
    }

    public void destroy() {
        config = null;
        logPrefix = null;
    }

}

